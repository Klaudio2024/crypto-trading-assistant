# Crypto Trading Assistant

Paper-trading-first, Spot-only trading assistant. **No live orders are implemented.**

## Safety
- Simulation and paper trading only
- No leverage, margin, futures, shorts, martingale, or averaging down
- Default risk: 0.5% per trade; daily limit 2%; weekly limit 5%; drawdown lock 10%
- Never store exchange secrets in this project

## Run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Test
```bash
pytest -q
```

## Current scope
This starter is a working safe foundation: bilingual dashboard, SQLite journal, risk guard, position sizing, paper order simulation, emergency lock, and calculation tests. Binance/Kraken adapters are intentionally interfaces only; live execution is disabled.
